# logica-de-programacao-essencial-dev
 Trata-se de práticas de lógica de programação nas quais eu fiz.
 Com desafios que participei também.
